#!/bin/bash
names=name.txt
avtomat=some_name.hmm
bacteria=bacteria.faa.gz
for var in $(cat $names | cut -d '.' -f 1); do
     echo "Название выравнивания: $var"
     hmmbuild $avtomat "$var.fa"
     hmmsearch $avtomat $bacteria>$var"_res.txt"
done
